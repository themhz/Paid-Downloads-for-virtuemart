DROP TABLE `#__virtuemart_payeddownload_downloads`;
DROP TABLE `#__virtuemart_payeddownload_orderfilepasswords`;
DROP TABLE `#__virtuemart_payeddownload_productfiles`;
DROP TABLE `#__virtuemart_payeddownload_visits`;
delete from ivf27_virtuemart_adminmenuentries where name='Payed Downloads';
delete from ivf27_virtuemart_adminmenuentries where name='Reporting';
